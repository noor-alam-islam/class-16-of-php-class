<?php

use App\Http\Controllers\BlogController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('home');
});

Route::resource('blogs', BlogController::class);

Route::get('/contact', function () {
    return view('contact');
});

